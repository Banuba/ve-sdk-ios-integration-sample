const prefabs = require("bnb_js/prefabs");

class HairStrands extends prefabs.Base {
    constructor(faceIndex=0) {
        super();

        /* strands colors params */
        const strands_mat = bnb.scene.getAssetManager().findMaterial("shaders/hair_strands/strands_color");
        this._strands_colors = [];
        for (let i = 0; i < 5; ++i) {
            const strandsParam = strands_mat.findParameter(`strands_hair_color${i}`);
            strandsParam && this._strands_colors.push(strandsParam);
        }
    }

    color(first, ...rest) {
        if (Array.isArray(first))
            return this.color(...first);

        const colors = [first, ...rest];

        for (let i = 0; i < 5; ++i)
            this._strands_colors[i].setVector4(prefabs.parseColor(colors[i] ?? "0 0 0 0"));
        
        return colors;
    }

    clear() {
        for (const color of this._strands_colors)
            color.setVector4(prefabs.parseColor("0 0 0 0"));
    }
}

exports = {
    HairStrands
}
